import json
import http.client
import bcrypt

def lambda_handler(event, context):
    action = event['action']
    value = event['value']

    # Calculating bcrypt hash
    salt = bcrypt.gensalt()
    hashed_value = bcrypt.hashpw(value.encode(), salt).decode()

    # Constructing the Lambda function's ARN
    arn = "arn:aws:lambda:{}:{}:function:{}".format(
        context.invoked_function_arn.split(":")[3],
        context.invoked_function_arn.split(":")[4],
        context.function_name
    )

    # Constructing the output JSON
    output_data = {
        "banner": "B00968392",
        "result": hashed_value,
        "arn": arn, 
        "action": action,  # Changed action to bcrypt
        "value": value
    }

    # Sending a POST request with the output_data
    url = "129.173.67.234"
    port = 8080
    path = "/serverless/end"
    headers = {"Content-Type": "application/json"}

    # Create a connection to the server
    connection = http.client.HTTPConnection(url, port)

    # Convert output_data to JSON string
    data = json.dumps(output_data)

    # Send the POST request
    connection.request("POST", path, data, headers)

    # Get the response
    response = connection.getresponse()

    if response.status == 200:
        print("POST request successful!")
    else:
        print("POST request failed with status code:", response.status)

    return output_data